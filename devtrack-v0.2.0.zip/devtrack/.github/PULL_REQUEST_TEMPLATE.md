## What does this change?

<!-- A short description and the user problem it solves. Link the issue: Closes #123 -->

## How was it tested?

- [ ] `npm test` passes
- [ ] `npm run build` passes
- [ ] Checked in the browser (desktop and mobile width) if the UI changed

## Checklist

- [ ] No fabricated data: every number shown comes from the GitHub API and is labeled for what it is
- [ ] New API calls use documented public endpoints and handle errors and rate limits
- [ ] User-controlled text is escaped (`escapeHtml` / `safeUrl`)
- [ ] No tokens, secrets or personal data are committed
- [ ] Docs and `CHANGELOG.md` updated if behavior changed
